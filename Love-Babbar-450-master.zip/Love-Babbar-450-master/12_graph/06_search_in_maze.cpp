/*
    ref: backtracking/1_rat_in_maze
*/