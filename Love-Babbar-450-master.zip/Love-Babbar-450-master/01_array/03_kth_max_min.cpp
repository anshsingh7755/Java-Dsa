/*
    link: https://practice.geeksforgeeks.org/problems/kth-smallest-element5635/1

    sol: https://www.geeksforgeeks.org/kth-smallestlargest-element-unsorted-array/
    or
    refer heap/5th_kth....cpp

*/


