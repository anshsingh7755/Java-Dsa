/*
    link: https://practice.geeksforgeeks.org/problems/word-wrap1646/1

    ref: 14_DP/58_word_wrap.cpp
*/

