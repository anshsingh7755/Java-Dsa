/*
    link: https://practice.geeksforgeeks.org/problems/stickler-theif-1587115621/1

    ref: 14_DP/24_max_sum_no_two_ele_are_adjacent.cpp
*/

