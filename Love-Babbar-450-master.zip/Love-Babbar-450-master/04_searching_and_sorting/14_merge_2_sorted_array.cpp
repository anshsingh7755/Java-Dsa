/*
    link: https://practice.geeksforgeeks.org/problems/merge-two-sorted-arrays5135/1

    ref: 1_array/12_merge_2_sorted_array.cpp
*/
