/*
    link: https://practice.geeksforgeeks.org/problems/print-anagrams-together/1

    ref: string/36_given_sequence_....
*/
